import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class GlobalService {
  private apiURL: string = environment.apiURL;

  constructor(private router:Router,private httpClient: HttpClient) { }

  
  logedIn() {
  return localStorage.getItem('role');
}

logOutUser(){
  localStorage.removeItem('role');
  localStorage.clear();
  this.router.navigate(['/']);

  }
  
  login(userDetails) {
   return this.httpClient.post<any>(this.apiURL+"logincheck/getUserDetails/",userDetails)
  }

}
