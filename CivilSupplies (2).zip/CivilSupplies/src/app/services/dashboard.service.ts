import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  private apiURL: string = environment.apiURL;

  constructor(private httpClient: HttpClient) { }

  getDistricts(){
    return this.httpClient.get<any>(this.apiURL+"districtslist/getDistricts/");
  }

  getMandals(district_id:number){
    return this.httpClient.post<any>(this.apiURL+"mandalslist/getMandals/",{district_id:district_id});
  }

  getDivisions(mandal_id:number){
    return this.httpClient.post<any>(this.apiURL+"revenuedivisionslist/getRevenueDivisions/",{mandal_id:mandal_id});
  }

  getSeasons(){
    return this.httpClient.get<any>(this.apiURL+"seasonslist/getSeasons/");
  }

  createDemand(demandData:any){
    return this.httpClient.post<any>(this.apiURL+"demandslist/createdemand/",demandData);
  }

  getDemandList(userData) {
    return this.httpClient.get<any>(this.apiURL+"demandslist/getalldemand/",userData);
  }

  
  createIndent(indentData:any){
    return this.httpClient.post<any>(this.apiURL+"indents/createindent/",indentData);
  }

  getIndents(userData){
    return this.httpClient.get<any>(this.apiURL + "indents/getallindent/",userData);
  }

  getBufferGodowns(mandal_id:number){
    return this.httpClient.post<any>(this.apiURL+"buffergodownlist/getGodowns/",{mandal_id:mandal_id});
  }

  getCommodities(){
    return this.httpClient.get<any>(this.apiURL+"bagmodelslist/getCommodities/");
  }

   approveIndent(indentData:any){
    return this.httpClient.post<any>(this.apiURL+"indents/indentapproval/",indentData);
  }

}
