import { Component, OnInit } from "@angular/core";
import { DashboardService } from "src/app/services/dashboard.service";
import Swal from 'sweetalert2';
import * as moment from 'moment';

@Component({
  selector: "app-approve-indent",
  templateUrl: "./approve-indent.component.html",
  styleUrls: ["./approve-indent.component.css"],
})
export class ApproveIndentComponent implements OnInit {
  approveIndents = [];
  indentData: any = {
    indent_id: 0,
    status: '',
    comments: '',
    user_id:+sessionStorage.getItem("user_id")
  };
  user_id = +sessionStorage.getItem("user_id");
  constructor(private dashboardService: DashboardService) {}
  first = 0;
  rows = 4;
   ngOnInit() {
     this.getAllIndents();
     
  }

  getAllIndents() {
    this.dashboardService.getIndents({ user_id: this.user_id}).subscribe((IndentsList: any) => {
      console.log(IndentsList);
      if (IndentsList.status) {
        this.approveIndents = IndentsList.response.reverse();
        console.log(this.approveIndents);
              this.approveIndents.forEach(demand => {
          demand.created_date=moment(demand.created_date).format("MMM DD YYYY")
        })
      }
    })
  }


  accept(indent_id) {
    let self = this;
    Swal.fire({
      input: "textarea",
      inputPlaceholder: "comments...",
      inputAttributes: {
        "aria-label": "comments"
      },
      allowOutsideClick:false,
      showCancelButton: true,
      inputValidator: (result) => {
        return !result && 'Please give comments...'
      }
    }).then(result => {
      if (result.value) {
        self.indentData.indent_id = indent_id;
        self.indentData.status = "approved";
        self.indentData.comments = result.value;
        self.dashboardService.approveIndent(self.indentData).subscribe(resp => {
          if (resp.status) {
            console.log(resp);
           Swal.fire("Accepted", resp.response, "success");
         }
       })
      }
    });
  }

  reject(indent_id) {
    let self = this;
    Swal.fire({
      title: 'Are you sure?',
      input: "textarea",
      inputPlaceholder: "comments...",
      inputAttributes: {
        "aria-label": "comments"
      },
      allowOutsideClick:false,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, reject it!',
      inputValidator: (result) => {
        return !result && 'Please give comments...'
      }
    }).then((result) => {

      if (result.value) {
        self.indentData.indent_id = indent_id;
        self.indentData.indent_id = indent_id;
        self.indentData.status = "rejected";
        self.indentData.comments = result.value;
        self.dashboardService.approveIndent(self.indentData).subscribe(resp => {
          if (resp.status) {
           Swal.fire("Rejected", "Indent Rejected Successfully..", "success");
         }
       })
      }
    })
  }
  next() {
    this.first = this.first + this.rows;
  }

  prev() {
    this.first = this.first - this.rows;
  }

  reset() {
    this.first = 0;
  }

  isLastPage(): boolean {
    return this.first === this.approveIndents.length - this.rows;
  }

  isFirstPage(): boolean {
    return this.first === 0;
  }
}
