import { Component, OnInit } from "@angular/core";
import { DashboardService } from "src/app/services/dashboard.service";
import { createDemand } from "src/app/models/createDemand";
import Swal from "sweetalert2";
import * as moment from 'moment';

@Component({
  selector: "app-create-demand",
  templateUrl: "./create-demand.component.html",
  styleUrls: ["./create-demand.component.css"],
})
export class CreateDemandComponent implements OnInit {
  districts = [];
  user_id = sessionStorage.getItem("user_id");
  mandals = [];
  seasons = [];
  createDispatch = [];
  divisions = [];
  bufferGodowns = [];
  createDemand = new createDemand();
  commodities = [];
  demandsList = [];
  constructor(private dashboardService: DashboardService) {}
  first = 0;
  rows = 4;
  ngOnInit() {
    this.createDispatch = [
      {
        mandal: "Rapthadu",
        godownName: "dummy",
        gunnyBags: "B-Twill(kg)",
        reqQty: "50 MT",
        date: "24-03-2020",
        comments: "",
      },
      {
        mandal: "G.Konduru",
        godownName: "dummy",
        gunnyBags: "B-Twill(kg)",
        reqQty: "50 MT",
        date: "24-03-2020",
        comments: "",
      },
      {
        mandal: "Rapthadu",
        godownName: "dummy",
        gunnyBags: "B-Twill(kg)",
        reqQty: "50 MT",
        date: "24-03-2020",
        comments: "",
      },
      {
        mandal: "G.Konduru",
        godownName: "dummy",
        gunnyBags: "B-Twill(kg)",
        reqQty: "50 MT",
        date: "24-03-2020",
        comments: "",
      },
    ];
    this.getDistricts();
    this.getSeasons();
    this.getCommodities();
    this.getAllDemands();
  }
  getDistricts() {
    this.dashboardService.getDistricts().subscribe(
      (dist) => {
        this.districts = dist.response;
        //  console.log(dist);
      },
      (err) => {
        console.log(err);
      }
    );
  }

  getMandals(distict_id) {
    this.dashboardService.getMandals(distict_id).subscribe(
      (mandal) => {
        this.mandals = mandal.response;
        // console.log(mandal);
      },
      (err) => {
        console.log(err);
      }
    );
  }

  getSeasons() {
    this.dashboardService.getSeasons().subscribe(
      (season) => {
        this.seasons = season.response;
        // console.log(this.seasons);
      },
      (err) => {
        console.log(err);
      }
    );
  }

  getRevenueDivisions(mandal_id) {
    this.dashboardService.getDivisions(mandal_id).subscribe(
      (divisions) => {
        this.divisions = divisions.response;
        // console.log(this.divisions);
      },
      (err) => {
        console.log(err);
      }
    );
    this.getBufferGodowns(mandal_id);
  }

  getBufferGodowns(mandal_id) {
    this.dashboardService.getBufferGodowns(mandal_id).subscribe(
      (godown) => {
        this.bufferGodowns = godown.response;
        // console.log(godown);
      },
      (err) => {
        console.log(err);
      }
    );
  }
  getCommodities() {
    this.dashboardService.getCommodities().subscribe(
      (commodity) => {
        this.commodities = commodity.response;
        // console.log(this.commodities);
      },
      (err) => {
        console.log(err);
      }
    );
  }

  createNewDemand() {
    this.createDemand.user_id = Number(this.user_id);
    console.log(this.createDemand);
    this.dashboardService.createDemand(this.createDemand).subscribe((resp) => {
      console.log(resp);
      if (resp.status) {
        this.createDemand = new createDemand();
        Swal.fire({ icon: "success", text: "Demand creted successfully" });
      } else {
        Swal.fire({ icon: "error", text: "Something Went Wrong" });
      }
    });
  }

  getAllDemands() {
    console.log(this.user_id);
    this.dashboardService
      .getDemandList({ user_id: Number(this.user_id) })
      .subscribe((demandsList: any) => {
        if (demandsList.status) {
          this.demandsList = demandsList.response.reverse();
        }
      });
  }
  next() {
    this.first = this.first + this.rows;
  }

  prev() {
    this.first = this.first - this.rows;
  }

  reset() {
    this.first = 0;
  }

  isLastPage(): boolean {
    return this.first === this.createDispatch.length - this.rows;
  }

  isFirstPage(): boolean {
    return this.first === 0;
  }
}
