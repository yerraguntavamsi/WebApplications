import { Component, OnInit } from '@angular/core';
import { DashboardService } from 'src/app/services/dashboard.service';
import * as moment from 'moment';
@Component({
  selector: 'app-district-wise-demand',
  templateUrl: './district-wise-demand.component.html',
  styleUrls: ['./district-wise-demand.component.css']
})
export class DistrictWiseDemandComponent implements OnInit {
  districtWiseDemand = [];
  user_id=+sessionStorage.getItem('user_id')
  constructor(private dashboardService:DashboardService) {}
  first = 0;  
  rows = 4;
  ngOnInit() {
    this.getAllDemands();
  }
  
   getAllDemands() {
    this.dashboardService.getDemandList({ user_id: Number(this.user_id)}).subscribe((demandsList:any) => {
      if (demandsList.status) {
        this.districtWiseDemand = demandsList.response.reverse();
        console.log(this.districtWiseDemand);
        this.districtWiseDemand.forEach(demand => {
          demand.created_date=moment(demand.created_date).format("MMM DD YYYY")
        })
      }
    })
  }
  next() {
    this.first = this.first + this.rows;
  }

  prev() {
    this.first = this.first - this.rows;
  }

  reset() {
    this.first = 0;
  }

  isLastPage(): boolean {
    return this.first === this.districtWiseDemand.length - this.rows;
  }

  isFirstPage(): boolean {
    return this.first === 0;
  }

}
