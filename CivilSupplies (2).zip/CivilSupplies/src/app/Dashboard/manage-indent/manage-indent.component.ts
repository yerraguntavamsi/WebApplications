import { Component, OnInit } from "@angular/core";
import { DashboardService } from 'src/app/services/dashboard.service';
import * as moment from 'moment';

@Component({
  selector: "app-manage-indent",
  templateUrl: "./manage-indent.component.html",
  styleUrls: ["./manage-indent.component.css"]
})
export class ManageIndentComponent implements OnInit {
  manageIndents = [];
  user_id = +sessionStorage.getItem('user_id');
  constructor(private dashboardService:DashboardService) {}
  first = 0;
  rows = 4;
  ngOnInit() {
      this.getAllIndents()
  }

  getAllIndents() {
    this.dashboardService.getIndents({ user_id: this.user_id}).subscribe((IndentsList: any) => {
      console.log(IndentsList);
      if (IndentsList.status) {
        this.manageIndents = IndentsList.response.reverse();
         this.manageIndents.forEach(demand => {
          demand.created_date=moment(demand.created_date).format("MMM DD YYYY")
        })
      }
    })
  }
  next() {
    this.first = this.first + this.rows;
  }

  prev() {
    this.first = this.first - this.rows;
  }

  reset() {
    this.first = 0;
  }

  isLastPage(): boolean {
    return this.first === this.manageIndents.length - this.rows;
  }

  isFirstPage(): boolean {
    return this.first === 0;
  }
}
