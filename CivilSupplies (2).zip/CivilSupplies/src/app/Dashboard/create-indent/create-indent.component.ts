import { Component, OnInit } from '@angular/core';
import { DashboardService } from 'src/app/services/dashboard.service';
import { createIndent } from 'src/app/models/createIndent';
import Swal from "sweetalert2";
import * as moment from 'moment';

@Component({
  selector: 'app-create-indent',
  templateUrl: './create-indent.component.html',
  styleUrls: ['./create-indent.component.css']
})
export class CreateIndentComponent implements OnInit {
  districtWiseDemand = [];
  createIndent: createIndent = new createIndent();
  user_id = +sessionStorage.getItem('user_id');
  constructor(private dashboardService:DashboardService) {}
  first = 0;  
  rows = 4;
  ngOnInit() {
    this.getAllDemands();
  }
  next() {
    this.first = this.first + this.rows;
  }
     getAllDemands() {
    this.dashboardService.getDemandList({ user_id: Number(this.user_id)}).subscribe((demandsList:any) => {
      if (demandsList.status) {
        this.districtWiseDemand = demandsList.response.reverse();
        console.log(this.districtWiseDemand);
             this.districtWiseDemand.forEach(demand => {
          demand.created_date=moment(demand.created_date).format("MMM DD YYYY")
        })
      }
    })
  }
 
  createNewIndent() {
    this.createIndent.user_id = this.user_id;
    this.createIndent.commodity_id = 1;
    this.createIndent.demand_id = 3;
    console.log(this.createIndent);
    this.dashboardService.createIndent(this.createIndent).subscribe((resp:any) => {
      if (resp.status) {
        this.createIndent = new createIndent();
        this.getAllDemands();
        Swal.fire({ icon: "success", text: "Indent creted successfully" });
      } else {
        Swal.fire({ icon: "error", text: "Something Went Wrong" });
      }
    });
  }

  cancelIndent() {
  this.createIndent = new createIndent();
  }
  prev() {
    this.first = this.first - this.rows;
  }

  reset() {
    this.first = 0;
  }

  isLastPage(): boolean {
    return this.first === this.districtWiseDemand.length - this.rows;
  }

  isFirstPage(): boolean {
    return this.first === 0;
  }
}
