import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { AppRoutingModule } from "./app-routing.module";
import { AppComponent } from "./app.component";
import { LoginComponent } from "./login/login.component";
import { DashboardComponent } from "./Dashboard/dashboard/dashboard.component";
import { CreateIndentComponent } from "./Dashboard/create-indent/create-indent.component";
import { ManageIndentComponent } from "./Dashboard/manage-indent/manage-indent.component";
import { CreateDemandComponent } from "./Dashboard/create-demand/create-demand.component";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HeaderComponent } from "./header/header.component";
import { SidebarComponent } from "./sidebar/sidebar.component";
import { FooterComponent } from "./footer/footer.component";
import { LayoutComponent } from "./dashboard/layout/layout.component";
import { ApproveIndentComponent } from "./Dashboard/approve-indent/approve-indent.component";
import { DistrictWiseDemandComponent } from "./Dashboard/district-wise-demand/district-wise-demand.component";
import { TableModule } from "primeng/table";
import { HttpClientModule } from "@angular/common/http";
import { DropdownModule } from "primeng/dropdown";
import { ButtonModule } from "primeng/button";
import { TabViewModule } from "primeng/tabview";
import { TooltipModule } from "primeng/tooltip";
import { MenuModule } from "primeng/menu";
import { CardModule } from "primeng/card";
import { PaginatorModule } from "primeng/paginator";
import {
  NgxUiLoaderConfig,
  NgxUiLoaderHttpModule,
  NgxUiLoaderModule,
  NgxUiLoaderRouterModule,
  PB_DIRECTION,
  POSITION,
  SPINNER
} from 'ngx-ui-loader';
  const ngxUiLoaderConfig: NgxUiLoaderConfig = {
  "bgsColor": "red",
  "bgsOpacity": 0.5,
  "bgsPosition": "bottom-right", "bgsSize": 60,
  "bgsType": "ball-spin-clockwise",
  "blur": 4,
  "fgsColor": "#00324F",
  "fgsPosition": "center-center",
  "fgsSize": 40,
  "fgsType": "ball-spin-clockwise",
  "gap": 24,
  "logoPosition": "center-center",
  "logoSize": 120,
  "logoUrl": "",
  "masterLoaderId": "master",
  "overlayBorderRadius": "0",
  "overlayColor": "rgba(250,250,250,0.4)",
  "pbColor": "red",
  "pbDirection": "ltr",
  "pbThickness": 3,
  "hasProgressBar": false,
  "text": "",
  "textColor": "#FFFFFF",
  "textPosition": "center-center"
};
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    CreateIndentComponent,
    ManageIndentComponent,
    CreateDemandComponent,
    HeaderComponent,
    SidebarComponent,
    FooterComponent,
    LayoutComponent,
    ApproveIndentComponent,
    DistrictWiseDemandComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
    TableModule,
    HttpClientModule,
    DropdownModule,
    ButtonModule,
    TabViewModule,
    TooltipModule,
    MenuModule,
    CardModule,
    PaginatorModule,
    NgxUiLoaderModule.forRoot(ngxUiLoaderConfig),
    NgxUiLoaderHttpModule.forRoot({ showForeground: true }),
  ],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
