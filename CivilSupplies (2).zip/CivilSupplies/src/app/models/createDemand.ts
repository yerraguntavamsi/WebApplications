export class createDemand {
  district_id: number;
  mandal_id: number;
  season_id: number;
  qty: number;
  revenue_division_id: number;
  buffer_godwon_id: number;
  bag_id :number;
  user_id :number;
  comment:string;
}