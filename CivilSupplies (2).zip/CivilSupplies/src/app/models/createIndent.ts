export class createIndent {
  user_id: number;
  qty: number;
  demand_id: number=3;
  commodity_id: number=1;
  comments: string;
}
