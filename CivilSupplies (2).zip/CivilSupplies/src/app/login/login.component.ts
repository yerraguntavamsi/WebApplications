import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { GlobalService } from '../services/global.service';
import Swal from "sweetalert2";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  userData = {
    username: "",
    password: ""
  };
  constructor(private router: Router,private globalService:GlobalService) {}

  ngOnInit() {
  }

  userCredentials() {
    switch (this.userData.username) {
      case "district":
        localStorage.setItem("role", "District Manager");
        break;
      case "manager":
        localStorage.setItem("role", "Marketing Manager");
        break;
      case "commissioner":
        localStorage.setItem("role", "Commissioner");
        break;
      // case "department":
      //   localStorage.setItem("role", "Finance Department");
      //   break;
      //   case "admin":
      //   localStorage.setItem("role", "Admin");
      //   break;
      case "default":
        "";
    }
    this.router.navigate(["/Dashboard/Home"]);
  }

  login() {
    this.globalService.login(this.userData).subscribe((resp) => {
      console.log(resp);
      if (resp.response.length) {
      sessionStorage.setItem('user_id', resp.response[0].userid);
      localStorage.setItem('role', resp.response[0].username)
      this.router.navigate(["/Dashboard/Home"]);
      } else {
        Swal.fire({
          text: "Invalid Credentials",
          icon: "warning"
        });
      }
     
    })
  }
}
