export const environment = {
  production: true,
  apiURL:'http://3.20.234.145:8000/scapi/'
};
